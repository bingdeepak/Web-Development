#include<string.h>
#include<sys/socket.h>
#include<stdio.h>
#include<arpa/inet.h>
#include<unistd.h>



short socketCreate()
{
	short hSocket;
	printf("Creating Socket");
	hSocket = socket(AF_INET, SOCK_STREAM, 0);
	return hSocket;
}


int socketConnect(int hSocket)
{
	int iRetval = -1;
	int serverPort = 8080;
	struct sockaddr_in remote = {0};
	
	remote.sin_addr.s_addr = inet_addr("127.0.0.1");
	remote.sin_family  = AF_INET;
	remote.sin_port = htons(serverPort);
	iRetval = connect(hSocket, (struct sockaddr *)&remote, sizeof(struct sockaddr_in));
	return iRetval;
}

int socketSend(int hSocket, char *message, int len)
{
	int shortRetVal = -1;
	shortRetVal = send(hSocket, message, len, 0);
	return shortRetVal;
}



int main()
{
	int hSocket, read_size;
	struct sockaddr_in server;
	char sendToServer[100] = {0};
	char serverReply[200]  = {0};
	char *invalid = "Wrong Password !";
	hSocket = socketCreate();
	if(hSocket == -1)
	{
		printf("Could not create socket\n");
		return 1;
	}
	printf("Socket created\n");
	if(socketConnect(hSocket) < 0 )
	{
		printf("Connect Failed.\n");
		return 1;
	}
	printf("Successfully connected\n");
	printf("Enter password : "); //Password is :- sayonara
	scanf("%s",sendToServer);
	if( socketSend(hSocket, sendToServer, strlen(sendToServer) ) < 0 )
	{
		printf("Send failed\n");
		return 1;
	}
	
	if(recv(hSocket, serverReply, 200, 0 ) < 0 )
	{
		printf("Receive failed\n");
		return 1;
	}
	printf("Server reply : - %s\n\n", serverReply);
	if(strcmp(serverReply, invalid) == 0 )
	{
		return 1;
	}

	printf("\n");
	
	memset(sendToServer, '\0', sizeof (sendToServer));
        memset(serverReply, '\0', sizeof (serverReply));
	
	printf("Enter message:- ");
	scanf("%s",sendToServer);
	if( socketSend(hSocket, sendToServer, strlen(sendToServer) ) < 0 )
	{
		printf("Send failed\n");
		return 1;
	}
	
	if(recv(hSocket, serverReply, 200, 0 ) < 0 )
	{
		printf("Receive failed\n");
		return 1;
	}
	printf("Server response : - %s\n\n", serverReply);
	printf("\n");
	close(hSocket);
	return 0;
}

	




	
	



