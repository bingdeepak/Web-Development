#include<string.h>
#include<sys/socket.h>
#include<stdio.h>
#include<arpa/inet.h>
#include<unistd.h>



short socketCreate()
{
	short hSocket;
	printf("Creating Socket\n");
	hSocket = socket(AF_INET, SOCK_STREAM, 0);
	return hSocket;
}
int bindCreatedSocket(int hSocket)
{
 
	 int iRetval=-1;
	 int ClientPort = 8080;
	 struct sockaddr_in  remote={0};
	 
	 
	 remote.sin_family = AF_INET;
	 remote.sin_addr.s_addr = htonl(INADDR_ANY);
	 remote.sin_port = htons(ClientPort);
	 iRetval = bind(hSocket,(struct sockaddr *)&remote,sizeof(remote));
	 
        return iRetval;
}

void fibonacci(int num, int ans[])
{
        int i;
	ans[0] = 0;
	ans[1] = 1;
	for(i = 2; i<=num; ++i)
	{
		ans[i] = ans[i-1] + ans[i-2];
	}
	

}

int main()
{
	int i,socket_desc, client_sock, c, read_size;
	struct sockaddr_in server, client;
	int numberFromClient = 0;
	char serverResponse[100];
	socket_desc  = socketCreate();
	if(socket_desc == -1)
	{
		printf("Could not create socket\n");
		return 1;
	}
	printf("Socket created\n");
	int opt = 1;
	if (setsockopt(socket_desc, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    	{
       		 perror("setsockopt");
       		 exit(1);
   	}
	if(bindCreatedSocket(socket_desc) <0 )
	{
		printf("Bind failed\n");
	}
	printf("Bind done\n");
	
	listen(socket_desc, 3);
	printf("Waiting for connections...");
	c = sizeof(struct sockaddr_in);
	client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
	if (client_sock < 0)
 	{
	 	printf("accept failed");
 		return 1;
 	}
	printf("Connnection accepted\n");
	
	if(recv(client_sock, &numberFromClient, 1*sizeof(int), 0) < 0 )
	{
		printf("Recv Failed\n");
		return 0;
	}

	printf("The number send by client is :%d\n",numberFromClient);
	int sum = (numberFromClient * (numberFromClient + 1 )) /2;
	for(i=0; i < sum; ++i)
		serverResponse[i] = '*';
	
	if(send(client_sock, serverResponse, sizeof(serverResponse)/sizeof(char), 0 ) < 0 )
	{
		printf("Send Failed\n");
		return 1;
	}
	close(client_sock);
	return 0;
}
	






















