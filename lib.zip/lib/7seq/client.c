#include<string.h>
#include<sys/socket.h>
#include<stdio.h>
#include<arpa/inet.h>
#include<unistd.h>



short socketCreate()
{
	short hSocket;
	printf("Creating Socket");
	hSocket = socket(AF_INET, SOCK_STREAM, 0);
	return hSocket;
}


int socketConnect(int hSocket)
{
	int iRetval = -1;
	int serverPort = 8080;
	struct sockaddr_in remote = {0};
	
	remote.sin_addr.s_addr = inet_addr("127.0.0.1");
	remote.sin_family  = AF_INET;
	remote.sin_port = htons(serverPort);
	iRetval = connect(hSocket, (struct sockaddr *)&remote, sizeof(struct sockaddr_in));
	return iRetval;
}

int socketSend(int hSocket, int *number)
{
	int shortRetVal = -1;
	shortRetVal = send(hSocket, number, 1*sizeof(int), 0);
	return shortRetVal;
}

int main()
{
	int hSocket, read_size;
	struct sockaddr_in server;
	int numberToServer;
	int serverResponse;
	
	hSocket = socketCreate();
	if(hSocket == -1)
	{
		printf("Could not create socket\n");
		return 1;
	}
	printf("Socket created\n");
	if(socketConnect(hSocket) < 0 )
	{
		printf("Connect Failed.\n");
		return 1;
	}
	printf("Successfully connected\n");
	printf("Enter numbers in sequence : ");
	int n = 0;
	int i;
	for( i=0; i<5; ++i)
	{
		scanf("%d",&n);
		numberToServer = n;
		if( socketSend(hSocket, &numberToServer) < 0 )
		{
			printf("Send failed\n");
			return 1;
		}
		
		if(recv(hSocket, &serverResponse, 1*sizeof(int), 0 ) < 0 )
		{
			printf("Receive failed\n");
			return 1;
		}
		printf("Server reply : - \n");
		printf("%d",serverResponse);
		printf("\n");
	}
	close(hSocket);
	return 0;
}

	




	
	



