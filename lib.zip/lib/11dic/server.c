#include<cstring>
#include<sys/socket.h>
#include<cstdio>
#include<arpa/inet.h>
#include<unistd.h>
#include <ctime>
#include<cstdlib>
#include<iostream>
#include<string>
#include<bits/stdc++.h>
using namespace std;


map<string,string> ans;

short socketCreate()
{
	short hSocket;
	printf("Creating Socket\n");
	hSocket = socket(AF_INET, SOCK_STREAM, 0);
	return hSocket;
}
int bindCreatedSocket(int hSocket)
{
 
	 int iRetval=-1;
	 int ClientPort = 8080;
	 struct sockaddr_in  remote={0};
	 
	 
	 remote.sin_family = AF_INET;
	 remote.sin_addr.s_addr = htonl(INADDR_ANY);
	 remote.sin_port = htons(ClientPort);
	 iRetval = bind(hSocket,(struct sockaddr *)&remote,sizeof(remote));
	 
        return iRetval;
}


int main()
{
	ans["seeding"] = "The arrangementd of positions in a tournament";
	ans["ambiguity"] = "Open to multiple interpretations";
	ans["lentivirus"] = "Any of a group of viruses, of the genus Lentivirus which have long incubation period";
	ans["giallolino"] = "The yellow oxide of lead";
	ans["mackerel"] = "An edible fish of family Scombridae, often speckled";
	int socket_desc, client_sock, c, read_size;
	struct sockaddr_in server, client;
	char client_message[200]={0};
 	char message[500] = {0};
	char *cstr;
 	const char *pMessage = "Word not present in Dictionary , Please try Again";
	socket_desc  = socketCreate();
	if(socket_desc == -1)
	{
		printf("Could not create socket\n");
		return 1;
	}
	printf("Socket created\n");
	int opt = 1;
	if (setsockopt(socket_desc, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    	{
       		 perror("setsockopt");
       		 exit(1);
   	}
	if(bindCreatedSocket(socket_desc) <0 )
	{
		printf("Bind failed\n");
	}
	printf("Bind done\n");
	
	listen(socket_desc, 3);
	printf("Waiting for connections...");
	c = sizeof(struct sockaddr_in);
	client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
	if (client_sock < 0)
 	{
	 	printf("accept failed");
 		return 1;
 	}
	printf("Connnection accepted\n");
	
	memset(client_message, '\0', sizeof client_message);
        memset(message, '\0', sizeof message);
	if(recv(client_sock, client_message, 200, 0) < 0 )
	{
		printf("Recv Failed\n");
		return 0;
	}
	
	printf("Client reply : %s\n",client_message);
	
	string str(client_message);
	bool wordFound = false;
	string meaning = "";
	map<string,string> :: iterator it;
	for(it = ans.begin(); it != ans.end(); it++)
	{
		if(it -> first == str)
		{
			wordFound = true;
			meaning = it ->second;
			cstr = new char[meaning.length() + 1];
			strcpy(cstr, meaning.c_str());
			break;
		}
	}
	if(wordFound == false)
	{
		strcpy(message, pMessage);
	}
	else
	{
			strcpy(message, cstr);
	}
		

	if(send(client_sock, message, strlen(message), 0 ) < 0 )
	{
		printf("Send Failed\n");
		return 1;
	}

	close(client_sock);
	return 0;
}
	

